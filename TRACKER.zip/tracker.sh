#!/bin/bash
java -jar ./progress-tracker-1.0-SNAPSHOT.jar "$@"
